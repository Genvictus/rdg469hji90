// Nama: Johann Christian Kandani
// NIM: 13521138
// Tanggal: 28 September 2022
// Topik: Mesin Kata
// Deskripsi: Praktikum longestword.c

#include <stdio.h>
#include "wordmachine.h"
#include "boolean.h"

Word currentWord;
boolean EndWord;

int main(){
	/* KAMUS */
	int maks;

	/* ALGORITMA */
	STARTWORD();
	maks = currentWord.Length;

	while(!EndWord){
		ADVWORD();
		if(maks < currentWord.Length)
			maks = currentWord.Length;
	}
	printf("%d\n", maks);
}