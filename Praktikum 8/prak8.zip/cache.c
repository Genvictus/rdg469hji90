// Nama: Johann Christian Kandani
// NIM: 13521138
// Tanggal: 27 Oktober 2022
// Topik: ADT Linked List
// Deskripsi: Praktikum cache.c

#include <stdio.h>
#include "listlinier.h"

int main(){
	/* KAMUS */
	int size, n;
	int i,j;
	int idx;
	double hit;
	List cache;
	ElType x, dump;

	/* ALGORITMA */
	scanf("%d", &size);
	scanf("%d", &n);

	CreateList(&cache);
	hit = 0;

	if(size != 0){
		scanf("%d", &x);
		printf("miss ");
		insertFirst(&cache, x);
		displayList(cache);
		printf("\n");
			
		/* i == n atau i == size */
	
		for(i=1; i<n; i++){
			scanf("%d", &x);
			idx = indexOf(cache, x);
			if(idx != IDX_UNDEF){
				printf("hit ");
				hit = hit + 1;
				deleteAt(&cache, idx, &dump);
			}
			else{
				printf("miss ");
				deleteLast(&cache, &dump);
			}
			insertFirst(&cache, x);
			displayList(cache);
			printf("\n");
		}
	}
	else{
		for(i = 0;i < n;i++){
			scanf("%d", &x);
			printf("miss []\n");
		}
	}
	if(n == 0){
		hit = 0;
	}
	else{
		hit = hit/n;
	}
	printf("hit ratio: %.2f\n", hit);
}